﻿using MSCLoader;
using System.Linq;
using UnityEngine;

namespace SteelRim14
{
    public class SteelRim14 : Mod
    {
        public override string ID => "SteelRim14";
        public override string Name => "SteelRim14";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
        public override string Description => "Replaces the 14' steel rim model.";
        public override Game SupportedGames => Game.MyWinterCar;

        public override void ModSetup()
        {
            SetupFunction(Setup.OnLoad, Mod_OnLoad);
        }

        private void Mod_OnLoad()
        {
            AssetBundle bundle = LoadAssets.LoadBundle("SteelRim14.Assets.shtamp.unity3d");
			GameObject bundlego = Object.Instantiate(bundle.LoadAsset<GameObject>("shtamp14.prefab"));
			bundle.Unload(false);
            Mesh rimmesh = bundlego.GetComponent<MeshFilter>().mesh;
            Object.Destroy(bundlego);

            foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "meshrim" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_steel14_offset")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = rimmesh;

                if (rim.GetComponent<MeshRenderer>().material.name == "RIM_PAINT_RUSTY")
                {
                    rim.GetComponent<MeshRenderer>().material.SetFloat("_UVSec", 1);
                }

                if (rim.GetComponent<MeshRenderer>().material.name == "RIM_PAINT_RUSTY (Instance)")
                {
                    rim.GetComponent<MeshRenderer>().material.SetFloat("_UVSec", 1);
                }
            }

            foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "meshrim" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("shtamp14")))
            {
                if (rim.GetComponent<MeshRenderer>().material.name == "RIM_PAINT_RUSTY")
                {
                    rim.GetComponent<MeshRenderer>().material.SetFloat("_UVSec", 1);
                }

                if (rim.GetComponent<MeshRenderer>().material.name == "RIM_PAINT_RUSTY (Instance)")
                {
                    rim.GetComponent<MeshRenderer>().material.SetFloat("_UVSec", 1);
                }
            }
        }
    }
}
