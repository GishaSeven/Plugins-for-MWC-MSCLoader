﻿using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;

namespace Autoload
{
    public class Autoload : Mod
    {
        public override string ID => "Autoload";
        public override string Name => "Autoload";
        public override string Author => "Roman266";
        public override string Version => "1.0.3";
        public override string Description => "Autoload saved game and auto import music files";
        public override Game SupportedGames => Game.MySummerCar_And_MyWinterCar;

        private static bool AutoloadDone = false;
        private static bool ExitToMenu = false;

        SettingsDropDownList AutoloadDropDownList;
        SettingsCheckBox SettingsToggleSongs;

        private SettingsKeybind ExitToMainMenuKeybind;

        public override void ModSetup()
        {
            SetupFunction(Setup.ModSettings, Mod_Settings);
            SetupFunction(Setup.Update, Mod_Update);
            SetupFunction(Setup.ModSettingsLoaded, Mod_SettingsLoaded);
        }

        private void Mod_Settings()
        {
            string[] AutoloadStrings = new string[] { "Autoload saved game when first entering the main menu", "Autoload saved game every time you enter the main menu", "Disable autoload saved game" };
            AutoloadDropDownList = Settings.AddDropDownList("autoloadlist", "Autoload saved games", AutoloadStrings, 0);
            Settings.AddText("Use keybind if you select 'Autoload saved game every time you enter the main menu' and want exit to main menu. By default it's left ALT + Q");
            SettingsToggleSongs = Settings.AddCheckBox("settingstogglesongs", "Auto import music files", false);

            ExitToMainMenuKeybind = Keybind.Add("exittomainmenukeybind", "Exit to menu", KeyCode.Q, KeyCode.LeftAlt);
        }

        private void Mod_SettingsLoaded()
        {
            MainMenuLoad();
        }

        private void MainMenuLoad()
        {
            if (AutoloadDropDownList.GetSelectedItemIndex() == 1)
            {
                if (!ExitToMenu)
                {
                    Application.LoadLevel("Game");
                }
            }
            else
            {
                if (AutoloadDropDownList.GetSelectedItemIndex() == 0)
                {
                    if (!AutoloadDone)
                    {
                        AutoloadDone = true;
                        Application.LoadLevel("Game");
                    }
                }
            }

            if (SettingsToggleSongs.GetValue())
            {
                GameObject.Find("Radio/Folk").GetComponents<PlayMakerFSM>()[1].enabled = true;
            }

            if(ExitToMenu)
            {
                ExitToMenu = false;
            }
        }

        private void Mod_Update()
        {
            if(ExitToMainMenuKeybind.GetKeybindDown())
            {
                Application.LoadLevel("MainMenu");
                ExitToMenu = true;
            }
        }
    }
}
