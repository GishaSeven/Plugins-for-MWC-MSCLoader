﻿using MSCLoader;
using UnityEngine;
using System.Linq;

namespace CorrisStuff
{
    public class CorrisStuff : Mod
    {
        public override string ID => "CorrisStuff";
        public override string Name => "CorrisStuff";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
        public override string Description => "Various stuff for Corris.";
        public override Game SupportedGames => Game.MyWinterCar;
		
		SettingsText DisclaimerText;
		SettingsCheckBox FendersToggle;
		SettingsDropDownList HeadlightsDropDownList;
		SettingsCheckBox BumpersToggle;
		SettingsCheckBox BootlidToggle;
		SettingsCheckBox RegplateToggle;
		
		GameObject CorrisGO;

        public override void ModSetup()
        {
            SetupFunction(Setup.OnLoad, Mod_OnLoad);
			SetupFunction(Setup.ModSettings, Mod_Settings);
        }

        private void Mod_Settings()
        {
            DisclaimerText = Settings.AddText("After making changes, exit the game and delete meshsave.txt file!");
			FendersToggle = Settings.AddCheckBox("togglefenders", "Real style front fenders", true);
			string[] HeadlightsStrings = new string[] { "Default", "Round without turn signal", "Square" };
            HeadlightsDropDownList = Settings.AddDropDownList("headlightlist", "Headlights", HeadlightsStrings, 2);
			BumpersToggle = Settings.AddCheckBox("togglebumpers", "Flat front bumpers (also changes the GT bumper)", true);
			BootlidToggle = Settings.AddCheckBox("togglebootlid", "Bigger black trim for LX/SLX bootlid", true);
			RegplateToggle = Settings.AddCheckBox("toggleregplate", "Even arrangement of register plates", true);
        }

        private void Mod_OnLoad()
        {
            CorrisGO = GameObject.Find("CORRIS");
			AssetBundle bundle = LoadAssets.LoadBundle("CorrisStuff.Assets.stuff.unity3d");
			GameObject LeftIndicator = CorrisGO.transform.Find("Simulation/Electricity/PowerON/Indicators/Left/FrontLeftIndicator").gameObject;
			GameObject LeftIndicator2 = LeftIndicator.transform.Find("indicator_FL").gameObject;
			GameObject RightIndicator = CorrisGO.transform.Find("Simulation/Electricity/PowerON/Indicators/Right/FrontRightIndicator").gameObject;
			GameObject RightIndicator2 = RightIndicator.transform.Find("indicator_RL").gameObject;
			
			if(FendersToggle.GetValue())
			{
				Material ATLAS_MOTOR = Resources.FindObjectsOfTypeAll<Material>().FirstOrDefault(g => g.name == "ATLAS_MOTOR_MWC");
				Material[] ATLAS_MOTOR2 = new Material[1] { ATLAS_MOTOR };
				
				GameObject bundlefenderl = Object.Instantiate(bundle.LoadAsset<GameObject>("body_fender_l.prefab"));
				GameObject bundlefenderr = Object.Instantiate(bundle.LoadAsset<GameObject>("body_fender_r.prefab"));
				GameObject bundleindicatorl = Object.Instantiate(bundle.LoadAsset<GameObject>("headlight_indicator_l.prefab"));
				GameObject bundleindicatorr = Object.Instantiate(bundle.LoadAsset<GameObject>("headlight_indicator_r.prefab"));
				Mesh fenderl = bundlefenderl.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlefenderl);
				Mesh fenderr = bundlefenderr.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlefenderr);
				Mesh indicatorl = bundleindicatorl.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleindicatorl);
				Mesh indicatorr = bundleindicatorr.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleindicatorr);
				
				foreach (GameObject fender in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Fender(VINXX)"))
				{
					if (fender.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_fender_l"))
					{
						fender.GetComponent<MeshFilter>().sharedMesh = fenderl;
					}

					if (fender.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_fender_r"))
					{
						fender.GetComponent<MeshFilter>().sharedMesh = fenderr;
					}
					
					if (fender.GetComponent<MeshRenderer>().materials.Length == 2)
					{
						Material[] oldMats = fender.GetComponent<MeshRenderer>().materials;
						Material[] newMats = new Material[oldMats.Length + 1];
						oldMats.CopyTo(newMats, 0);
						ATLAS_MOTOR2.CopyTo(newMats, 2);
						fender.GetComponent<MeshRenderer>().materials = newMats;
					}
                }
			
				GameObject PrefabL = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN410").gameObject;
				PrefabL.GetComponent<MeshFilter>().sharedMesh = fenderl;
				Material[] oldMatsL = PrefabL.GetComponent<MeshRenderer>().materials;
				Material[] newMatsL = new Material[oldMatsL.Length + 1];
				oldMatsL.CopyTo(newMatsL, 0);
				ATLAS_MOTOR2.CopyTo(newMatsL, 2);
				PrefabL.GetComponent<MeshRenderer>().materials = newMatsL;
			
				GameObject PrefabR = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN409").gameObject;
				PrefabR.GetComponent<MeshFilter>().sharedMesh = fenderr;
				Material[] oldMatsR = PrefabR.GetComponent<MeshRenderer>().materials;
				Material[] newMatsR = new Material[oldMatsR.Length + 1];
				oldMatsR.CopyTo(newMatsR, 0);
				ATLAS_MOTOR2.CopyTo(newMatsR, 2);
				PrefabR.GetComponent<MeshRenderer>().materials = newMatsR;
			
				LeftIndicator.transform.localPosition = new Vector3 (-0.74f, 0.256f, 1.995f);
				LeftIndicator2.transform.localPosition = new Vector3 (0.006f, 0f, -0.063f);
				LeftIndicator2.GetComponent<MeshFilter>().sharedMesh = indicatorl;
			
				RightIndicator.transform.localPosition = new Vector3 (0.74f, 0.256f, 1.995f);
				RightIndicator2.transform.localPosition = new Vector3 (-0.006f, 0f, -0.063f);
				RightIndicator2.GetComponent<MeshFilter>().sharedMesh = indicatorl;
			}
			
			if(HeadlightsDropDownList.GetSelectedItemIndex() == 1)
			{
				GameObject bundleheadlight = Object.Instantiate(bundle.LoadAsset<GameObject>("headlight_frame.prefab"));
				Mesh headlight = bundleheadlight.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleheadlight);
				GameObject bundlegrillel = Object.Instantiate(bundle.LoadAsset<GameObject>("body_grille4.prefab"));
				Mesh grillel = bundlegrillel.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillel);
				GameObject bundlegrillelx = Object.Instantiate(bundle.LoadAsset<GameObject>("body_grille.prefab"));
				Mesh grillelx = bundlegrillelx.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillelx);
				GameObject bundlegrilleslx = Object.Instantiate(bundle.LoadAsset<GameObject>("body_grille3.prefab"));
				Mesh grilleslx = bundlegrilleslx.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrilleslx);
				GameObject bundlegrillegt = Object.Instantiate(bundle.LoadAsset<GameObject>("body_grille5.prefab"));
				Mesh grillegt = bundlegrillegt.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillegt);
			
				foreach (GameObject headlights in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Head Light Assembly(VINXX)"))
				{
					headlights.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN401").gameObject.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN402").gameObject.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				
				foreach (GameObject grille in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Grille(VINXX)"))
				{
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille4"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grillel;
					}
					
					if (grille.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("ID").Value.Contains("VIN413B"))
					{
						if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille"))
						{
							grille.GetComponent<MeshFilter>().sharedMesh = grillelx;
						}
					}
					
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille3"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grilleslx;
					}
					
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille5"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grillegt;
					}
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413").gameObject.GetComponent<MeshFilter>().sharedMesh = grillel;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413B").gameObject.GetComponent<MeshFilter>().sharedMesh = grillelx;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413C").gameObject.GetComponent<MeshFilter>().sharedMesh = grilleslx;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413D").gameObject.GetComponent<MeshFilter>().sharedMesh = grillegt;
				
				if(!FendersToggle.GetValue())
				{
					LeftIndicator.GetComponent<Light>().enabled = false;
					LeftIndicator2.GetComponent<MeshRenderer>().enabled = false;
					RightIndicator.GetComponent<Light>().enabled = false;
					RightIndicator2.GetComponent<MeshRenderer>().enabled = false;
				}
			}
			
			if(HeadlightsDropDownList.GetSelectedItemIndex() == 2)
			{
				GameObject bundleheadlight = Object.Instantiate(bundle.LoadAsset<GameObject>("square_headlight_frame.prefab"));
				Mesh headlight = bundleheadlight.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleheadlight);
				GameObject bundleheadlightglass = Object.Instantiate(bundle.LoadAsset<GameObject>("square_headlight_glass.prefab"));
				Mesh headlightglass = bundleheadlightglass.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleheadlightglass);
				GameObject bundlegrillel = Object.Instantiate(bundle.LoadAsset<GameObject>("square_body_grille4.prefab"));
				Mesh grillel = bundlegrillel.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillel);
				GameObject bundlegrillelx = Object.Instantiate(bundle.LoadAsset<GameObject>("square_body_grille.prefab"));
				Mesh grillelx = bundlegrillelx.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillelx);
				GameObject bundlegrilleslx = Object.Instantiate(bundle.LoadAsset<GameObject>("square_body_grille3.prefab"));
				Mesh grilleslx = bundlegrilleslx.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrilleslx);
				GameObject bundlegrillegt = Object.Instantiate(bundle.LoadAsset<GameObject>("square_body_grille5.prefab"));
				Mesh grillegt = bundlegrillegt.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillegt);
			
				foreach (GameObject headlights in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Head Light Assembly(VINXX)"))
				{
					headlights.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
					headlights.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
					headlights.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshRenderer>().material.color = new Color32(157,157,157,255);

                    if (headlights.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("ID").Value.Contains("VIN401"))
					{
						headlights.transform.Find("Bolts").transform.GetChild(1).transform.localPosition = new Vector3 (0.212f, 0.0272f, 0.0044f);
						headlights.transform.Find("Trigger_Lightbulb").transform.localPosition = new Vector3 (0.051f, 0f, 0.001f);
					}
					
					if (headlights.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("ID").Value.Contains("VIN402"))
					{
						headlights.transform.Find("Bolts").transform.GetChild(0).transform.localPosition = new Vector3 (-0.212f, 0.0272f, 0.0044f);
						headlights.transform.Find("Trigger_Lightbulb").transform.localPosition = new Vector3 (-0.051f, 0f, 0.001f);
					}
				}
				
				GameObject PrefabLeft = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN401");
				PrefabLeft.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				PrefabLeft.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				PrefabLeft.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshRenderer>().material.color = new Color32(157,157,157,255);
				PrefabLeft.transform.Find("Bolts").transform.GetChild(1).transform.localPosition = new Vector3 (0.212f, 0.0272f, 0.0044f);
				PrefabLeft.transform.Find("Trigger_Lightbulb").transform.localPosition = new Vector3 (0.051f, 0f, 0.001f);
				GameObject PrefabRight = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN402");
				PrefabRight.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				PrefabRight.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				PrefabRight.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshRenderer>().material.color = new Color32(157,157,157,255);
				PrefabRight.transform.Find("Bolts").transform.GetChild(0).transform.localPosition = new Vector3 (-0.212f, 0.0272f, 0.0044f);
				PrefabRight.transform.Find("Trigger_Lightbulb").transform.localPosition = new Vector3 (-0.051f, 0f, 0.001f);
				
				CorrisGO.transform.Find("Simulation/Electricity/PowerON/BeamsShort/BeamShortLeft/headlight_FL").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				CorrisGO.transform.Find("Simulation/Electricity/PowerON/BeamsShort/BeamShortRight/headlight_RL").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				CorrisGO.transform.Find("Simulation/Electricity/PowerON/BeamsLong/BeamLongLeft/headlight_FL").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				CorrisGO.transform.Find("Simulation/Electricity/PowerON/BeamsLong/BeamLongRight/headlight_RL").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				
				foreach (GameObject grille in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Grille(VINXX)"))
				{
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille4"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grillel;
					}
					
					if (grille.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("ID").Value.Contains("VIN413B"))
					{
						if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille"))
						{
							grille.GetComponent<MeshFilter>().sharedMesh = grillelx;
						}
					}
					
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille3"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grilleslx;
					}
					
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille5"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grillegt;
					}
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413").gameObject.GetComponent<MeshFilter>().sharedMesh = grillel;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413B").gameObject.GetComponent<MeshFilter>().sharedMesh = grillelx;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413C").gameObject.GetComponent<MeshFilter>().sharedMesh = grilleslx;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413D").gameObject.GetComponent<MeshFilter>().sharedMesh = grillegt;
				
				if(!FendersToggle.GetValue())
				{
					LeftIndicator.GetComponent<Light>().enabled = false;
					LeftIndicator2.GetComponent<MeshRenderer>().enabled = false;
					RightIndicator.GetComponent<Light>().enabled = false;
					RightIndicator2.GetComponent<MeshRenderer>().enabled = false;
				}
			}
			
			if(BumpersToggle.GetValue())
			{
				GameObject bundlebumper1 = Object.Instantiate(bundle.LoadAsset<GameObject>("body_bumper_f.prefab"));
				Mesh bumper1 = bundlebumper1.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlebumper1);
				GameObject bundlebumper2 = Object.Instantiate(bundle.LoadAsset<GameObject>("body_bumper_f2.prefab"));
				Mesh bumper2 = bundlebumper2.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlebumper2);
				GameObject bundlebumper3 = Object.Instantiate(bundle.LoadAsset<GameObject>("body_bumper_f3.prefab"));
				Mesh bumper3 = bundlebumper3.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlebumper3);
				
				foreach (GameObject bumper in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Bumper(VINXX)"))
				{
					if (bumper.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Code").Value.Contains("A"))
					{
						if (bumper.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bumper_f"))
						{
							bumper.GetComponent<MeshFilter>().sharedMesh = bumper1;
						}
					}
					
					if (bumper.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bumper_f2"))
					{
						bumper.GetComponent<MeshFilter>().sharedMesh = bumper2;
					}
					
					if (bumper.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bumper_f3"))
					{
						bumper.GetComponent<MeshFilter>().sharedMesh = bumper3;
					}
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN405").gameObject.GetComponent<MeshFilter>().sharedMesh = bumper1;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN405B").gameObject.GetComponent<MeshFilter>().sharedMesh = bumper2;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN405C").gameObject.GetComponent<MeshFilter>().sharedMesh = bumper3;
			}
			
			if(BootlidToggle.GetValue())
			{
				GameObject bundlebootlidtrim = Object.Instantiate(bundle.LoadAsset<GameObject>("body_bootlid_trim.prefab"));
				Mesh bootlidtrim = bundlebootlidtrim.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlebootlidtrim);
				
				foreach (GameObject bootlid in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Bootlid(VINXX)"))
				{
					if (!bootlid.transform.Find("trim").gameObject.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bootlid_trim2"))
					{
						if (bootlid.transform.Find("trim").gameObject.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bootlid_trim"))
						{
							bootlid.transform.Find("trim").gameObject.GetComponent<MeshFilter>().sharedMesh = bootlidtrim;
						}
					}
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN412").transform.Find("trim").gameObject.GetComponent<MeshFilter>().sharedMesh = bootlidtrim;
			}
			
			if(RegplateToggle.GetValue())
			{
				CorrisGO.transform.Find("Assemblies/VINP_RegPlateF").transform.localEulerAngles = new Vector3 (350f, 0f, 90f);
				CorrisGO.transform.Find("Assemblies/VINP_RegPlateR").transform.localEulerAngles = new Vector3 (15f, 0f, 270f);
			}
			
			bundle.Unload(false);
        }
    }
}
