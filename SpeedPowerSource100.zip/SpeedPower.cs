﻿using HutongGames.PlayMaker;
using MSCLoader;
using System;
using UnityEngine;

namespace SpeedPower
{
    public class SpeedPower : Mod
    {
        public override string ID => "SpeedPower";
        public override string Name => "SpeedPower";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
        public override string Description => "Shows Corris speed, rpm, power, torque,tire grip, mass.";
        public override Game SupportedGames => Game.MyWinterCar;
		
		SettingsCheckBox AutoShowToggle;
		SettingsSlider SliderPositionX;
		SettingsSlider SliderPositionY;
		SettingsCheckBox SpeedToggle;
		SettingsCheckBox PowerToggle;
		SettingsCheckBox GripToggle;
		SettingsCheckBox MassToggle;
		
		SettingsKeybind ShowHUDKeybind;
		SettingsKeybind ResetPower;
		
		GameObject SpeedPowerHud;
		string HudYellowText;
		string HudWhiteText;
		string SpeedString;
		string PowerString;
		string GripString;
		string MassString;
		string SpeedStringUpd;
		string PowerStringUpd;
		string GripStringUpd;
		string MassStringUpd;
		Drivetrain CorrisDrivetrain;
		Rigidbody CorrisRigidbody;
		TextMesh SPHudYellowTextMesh;
		TextMesh SPHudYellowTextMeshS;
		TextMesh SPHudWhiteTextMesh;
		TextMesh SPHudWhiteTextMeshS;
		bool Started;
		FsmFloat speedfsm;
		float MaxPower;
		float MaxPowerRPM;
		float MaxTorque;
		float MaxTorqueRPM;
		Wheel CorrisWheel;

        public override void ModSetup()
        {
            SetupFunction(Setup.ModSettings, Mod_Settings);
			SetupFunction(Setup.ModSettingsLoaded, Mod_SettingsLoaded);
			SetupFunction(Setup.OnLoad, Mod_OnLoad);
            SetupFunction(Setup.Update, Mod_Update);
			SetupFunction(Setup.FixedUpdate, Mod_FixedUpdate);
        }
		
		private void Mod_Settings()
        {
			AutoShowToggle = Settings.AddCheckBox("toggleautoshow", "Auto show HUD when engine running", false);
			SliderPositionX = Settings.AddSlider("sliderpositionx", "Vertical position", -40f, 40f, 0f, ApplySettings);
			SliderPositionY = Settings.AddSlider("sliderpositiony", "Horizontal position", -40f, 40f, 0f, ApplySettings);
			SpeedToggle = Settings.AddCheckBox("togglespeed", "Show speed and rpm", true, ApplySettings);
			PowerToggle = Settings.AddCheckBox("togglepower", "Show power and torque", true, ApplySettings);
			GripToggle = Settings.AddCheckBox("togglepower", "Show tire grip", true, ApplySettings);
			MassToggle = Settings.AddCheckBox("togglemass", "Show mass", true, ApplySettings);
			
			ShowHUDKeybind = Keybind.Add("showhudkeybind", "Show HUD", KeyCode.S, KeyCode.LeftControl);
			ResetPower = Keybind.Add("resetpower", "Reset power and torque results", KeyCode.R);
        }
		
		private void Mod_SettingsLoaded()
        {
            ApplySettings();
        }
		
		private void Mod_OnLoad()
        {
            GameObject CorrisGO = GameObject.Find("CORRIS").gameObject;
			CorrisDrivetrain = CorrisGO.GetComponent<Drivetrain>();
			CorrisRigidbody = CorrisGO.GetComponent<Rigidbody>();
			
			GameObject HUD = GameObject.Find("GUI/HUD").gameObject;
			GameObject FPSYellow = HUD.transform.Find("FPS/HUDLabel").gameObject;
			
			SpeedPowerHud = new GameObject();
			SpeedPowerHud.name = "SpeedPowerHud";
			SpeedPowerHud.transform.parent = HUD.transform;
			SpeedPowerHud.transform.localPosition = new Vector3(SliderPositionX.GetValue(), SliderPositionY.GetValue(), 0f);
			SpeedPowerHud.transform.localEulerAngles = Vector3.zero;
			SpeedPowerHud.transform.localScale = Vector3.one;
			
			GameObject SpeedPowerHudYellow = GameObject.Instantiate(FPSYellow, Vector3.zero, Quaternion.identity) as GameObject;
			SpeedPowerHudYellow.transform.parent = SpeedPowerHud.transform;
			SpeedPowerHudYellow.transform.localPosition = Vector3.zero;
			SpeedPowerHudYellow.transform.localEulerAngles = Vector3.zero;
			SpeedPowerHudYellow.transform.localScale = Vector3.one;
			SPHudYellowTextMesh = SpeedPowerHudYellow.GetComponent<TextMesh>();
			SPHudYellowTextMeshS = SpeedPowerHudYellow.transform.GetChild(0).gameObject.GetComponent<TextMesh>();
			SPHudYellowTextMesh.alignment = TextAlignment.Right;
			SPHudYellowTextMeshS.alignment = TextAlignment.Right;
			
			GameObject SpeedPowerHudWhite = GameObject.Instantiate(FPSYellow, Vector3.zero, Quaternion.identity) as GameObject;
			SpeedPowerHudWhite.transform.parent = SpeedPowerHud.transform;
			SpeedPowerHudWhite.transform.localPosition = new Vector3(0.15f, 0f, 0f);
			SpeedPowerHudWhite.transform.localEulerAngles = Vector3.zero;
			SpeedPowerHudWhite.transform.localScale = Vector3.one;
			SPHudWhiteTextMesh = SpeedPowerHudWhite.GetComponent<TextMesh>();
			SPHudWhiteTextMeshS = SpeedPowerHudWhite.transform.GetChild(0).gameObject.GetComponent<TextMesh>();
			SPHudWhiteTextMesh.color = new Color32(255, 255, 255, 255);
			SPHudWhiteTextMesh.anchor = TextAnchor.UpperLeft;
			SPHudWhiteTextMeshS.anchor = TextAnchor.UpperLeft;
			
			ApplySettings();
			SpeedPowerHud.SetActive(false);
			
			speedfsm = FsmVariables.GlobalVariables.FindFsmFloat("SpeedKMH");
			CorrisWheel = CorrisGO.transform.Find("PhysicalAssemblies/FRONT/AxleFront/LinkFL/ToeFL/DamagePivotFL/WHEELc_FL").gameObject.GetComponent<Wheel>();
        }
		
		private void ApplySettings()
        {
			if (Application.loadedLevelName == "GAME")
			{ 
                if (SpeedToggle.GetValue())
				{
					SpeedString = "\nSPEED\nRPM";
				}
				else
				{
					SpeedString = null;
				}
				
				if(PowerToggle.GetValue())
				{
					PowerString = "\nPOWER\nTORQUE";
				}
				else
				{
					PowerString = null;
				}
				
				if(GripToggle.GetValue())
				{
					GripString = "\nGRIP";
				}
				else
				{
					GripString = null;
				}
					
				if(MassToggle.GetValue())
				{
					MassString = "\nMASS";
				}
				else
				{
					MassString = null;
				}
				
				HudYellowText = SpeedString + PowerString + GripString + MassString;
				
				SPHudYellowTextMesh.text = HudYellowText;
				SPHudYellowTextMeshS.text = HudYellowText;
				
				SpeedPowerHud.transform.localPosition = new Vector3(SliderPositionX.GetValue(), SliderPositionY.GetValue(), 0f);
            }
        }

        private void Mod_Update()
        {
            if(ShowHUDKeybind.GetKeybindDown())
            {
                SpeedPowerHud.SetActive(!SpeedPowerHud.activeSelf);
            }
			
			if(PowerToggle.GetValue() && SpeedPowerHud.activeSelf)
			{
				if(((CorrisDrivetrain.torque * 0.73756f) * CorrisDrivetrain.rpm) / 5252f  > MaxPower)
				{
					MaxPower = ((CorrisDrivetrain.torque * 0.73756f) * CorrisDrivetrain.rpm) / 5252f;
					MaxPowerRPM = CorrisDrivetrain.rpm;
				}
			
				if(CorrisDrivetrain.torque * 0.73756f > MaxTorque)
				{
					MaxTorque = CorrisDrivetrain.torque * 0.73756f;
					MaxTorqueRPM = CorrisDrivetrain.rpm;
				}
			}
			
			if(ResetPower.GetKeybindDown())
			{
				MaxPower = 0;
				MaxPowerRPM = 0;
				MaxTorque = 0;
				MaxTorqueRPM = 0;
			}
        }
		
		private void Mod_FixedUpdate()
        {
            if(AutoShowToggle.GetValue())
			{
				if(CorrisDrivetrain.rpm > 300)
				{
					if(!Started)
					{
						SpeedPowerHud.SetActive(true);
						Started = true;
					}
				}
				else
				{
					if(Started)
					{
						SpeedPowerHud.SetActive(false);
						Started = false;
					}
				}
			}
			
			if(SpeedPowerHud.activeSelf)
			{
				if (SpeedToggle.GetValue())
				{
					SpeedStringUpd = "\n" + Mathf.Round(speedfsm.Value) + "\n" + Mathf.Round(CorrisDrivetrain.rpm);
				}
				else
				{
					SpeedStringUpd = null;
				}
				
				if(PowerToggle.GetValue())
				{
					PowerStringUpd = "\n" + Mathf.Round(MaxPower) + " at " + Mathf.Round(MaxPowerRPM) + "\n" + Mathf.Round(MaxTorque) + " at " + Mathf.Round(MaxTorqueRPM);
				}
				else
				{
					PowerStringUpd = null;
				}
				
				if(GripToggle.GetValue())
				{
					GripStringUpd = "\n" + Math.Round(CorrisWheel.forwardGripFactor, 2);
				}
				else
				{
					GripStringUpd = null;
				}
					
				if(MassToggle.GetValue())
				{
					MassStringUpd = "\n" + Math.Round(CorrisRigidbody.mass, 2);
				}
				else
				{
					MassStringUpd = null;
				}
				
				HudWhiteText = SpeedStringUpd + PowerStringUpd + GripStringUpd + MassStringUpd;
				SPHudWhiteTextMesh.text = HudWhiteText;
				SPHudWhiteTextMeshS.text = HudWhiteText;
			}
        }
    }
}
