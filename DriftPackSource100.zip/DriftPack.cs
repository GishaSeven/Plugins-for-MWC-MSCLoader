﻿using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;
using HutongGames.PlayMaker.Actions;

namespace DriftPack
{
    public class DriftPack : Mod
    {
        public override string ID => "DriftPack";
        public override string Name => "DriftPack";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
        public override string Description => "Steering angle lock, countersteering, differential locking coefficient, anti overheating, rev limiter, quick engine start, ambient temperature.";
        public override Game SupportedGames => Game.MyWinterCar;
		
		SettingsCheckBox ToggleWarming;
		SettingsSlider SliderWarmingMin;
		SettingsSlider SliderWarmingMax;
		SettingsText WarmingText;
		SettingsCheckBox ToggleFuelFix;
		SettingsCheckBox ToggleRevLimit;
		SettingsSlider SliderRevLimit;
		SettingsCheckBox ToggleAngleLock;
		SettingsSlider SliderAngleLock;
		SettingsText AngleLockText;
		SettingsCheckBox ToggleCounter;
		SettingsSlider SliderCounter;
		SettingsText CounterText;
		SettingsCheckBox ToggleOverheating;
		SettingsCheckBox ToggleDiff;
		SettingsSlider SliderDiff;
		SettingsText DiffText;
		GameObject fuelgo;
		PlayMakerFSM fuelbool;
		GameObject startersound;
		HutongGames.PlayMaker.Actions.FloatClamp ambienttemp;
		bool waitingstart;
		Drivetrain corrisdrivetrain;
		PlayMakerFSM rackpm;
		AxisCarController corriscontroller;
		Wheel corrisfl;
		Wheel corrisfr;
		Wheel corrisrl;
		GameObject corrisgo;
		float slip1;
		float slip2;
		FsmFloat enginetemp;
		PlayMakerFSM diffpm;
		
        public override void ModSetup()
        {
            SetupFunction(Setup.ModSettings, Mod_Settings);
			SetupFunction(Setup.ModSettingsLoaded, Mod_SettingsLoaded);
			SetupFunction(Setup.OnLoad, Mod_OnLoad);
            SetupFunction(Setup.Update, Mod_Update);
			SetupFunction(Setup.FixedUpdate, Mod_FixedUpdate);
        }
		
        private void Mod_Settings()
        {
            ToggleAngleLock = Settings.AddCheckBox("toggleanglelock", "Steering angle lock", true, AngleLock);
			SliderAngleLock = Settings.AddSlider("slideranglelock", "Max angle", 20f, 60f, 45f, AngleLock);
			AngleLockText = Settings.AddText("Original game values: 26 degrees for 'Steering rack 26' and 33 degrees for 'Steering rack 33'. Disable 'Steering help' in game settings to get changes while the car is moving.");
			ToggleCounter = Settings.AddCheckBox("togglecounter", "Countersteering", true, Counter);
			SliderCounter = Settings.AddSlider("slidercounter", "Demultiplier", 1f, 100f, 30f, Counter);
			CounterText = Settings.AddText("If you do not press the steering left or right button, the wheels will turn in the direction of the skid on their own, this is how properly built IRL drift cars work. You can change how much the wheels will turn depending on the strength of the skid.");
			ToggleDiff = Settings.AddCheckBox("togglediff", "Differential locking coefficient", true, DiffCoef);
			SliderDiff = Settings.AddSlider("sliderdiff", "Coefficient", 0f, 100f, 100f, DiffCoef);
			DiffText = Settings.AddText("Original game values: 0 for open rear axle and 49 for LSD rear axle.");
			ToggleOverheating = Settings.AddCheckBox("toggleoverheating", "Anti overheating", true);
			ToggleRevLimit = Settings.AddCheckBox("togglerevlimit", "Rev limiter", false, RevLimit);
			SliderRevLimit = Settings.AddSlider("sliderrevlimit", "Max RPM", 1000f, 12000f, 8000f, RevLimit);
			ToggleFuelFix = Settings.AddCheckBox("togglefuel", "Ignoring fuel problems while cranking (quick engine start)", true);
			ToggleWarming = Settings.AddCheckBox("togglewarming", "Ambient temperature", true, Warming);
			SliderWarmingMin = Settings.AddSlider("sliderwarmingmin", "Min ambient temperature", -100f, 100f, 5f, Warming);
			SliderWarmingMax = Settings.AddSlider("sliderwarmingmax", "Max ambient temperature", -100f, 100f, 10f, Warming);
			WarmingText = Settings.AddText("Original game values: -66 and -1.21 degrees Celsius. My values ​​are intended to defrost the car windows and prevent the player from shaking from the cold.");
        }
		
		private void Mod_SettingsLoaded()
        {
            AngleLock();
			Counter();
			RevLimit();
			Warming();
			DiffCoef();
        }
		
		private void Mod_OnLoad()
        {
            corrisgo = GameObject.Find("CORRIS").gameObject;
			//Angle lock
			rackpm = corrisgo.transform.FindChild("PhysicalAssemblies/FRONT/AxleFront/VINP_SteeringRack").gameObject.GetComponent<PlayMakerFSM>();
			if(ToggleAngleLock.GetValue())
			{
				AngleLock();
			}
			//Countersteering
			corriscontroller = corrisgo.GetComponent<AxisCarController>();
			corrisfl = corrisgo.transform.Find("PhysicalAssemblies/FRONT/AxleFront/LinkFL/ToeFL/DamagePivotFL/WHEELc_FL").gameObject.GetComponent<Wheel>();
			corrisfr = corrisgo.transform.Find("PhysicalAssemblies/FRONT/AxleFront/LinkFR/ToeFR/DamagePivotFR/WHEELc_FR").gameObject.GetComponent<Wheel>();
			corrisrl = corrisgo.transform.Find("PhysicalAssemblies/REAR/RearWheelsStatic/WHEELc_RL").gameObject.GetComponent<Wheel>();
			//Differential coefficient
			diffpm = corrisgo.transform.FindChild("Simulation/Systems/Drivetrain").gameObject.GetComponents<PlayMakerFSM>()[0];
            if (ToggleDiff.GetValue())
            {
                DiffCoef();
            }
            //Anti overheating
            enginetemp = FsmVariables.GlobalVariables.FindFsmFloat("EngineTemp");
			//Rev limiter
			corrisdrivetrain = corrisgo.GetComponent<Drivetrain>();
			if(ToggleRevLimit.GetValue())
			{
				RevLimit();
			}
			//Fuel fix
			fuelgo = corrisgo.transform.Find("Simulation/Engine/Fuel").gameObject;
			fuelbool = corrisgo.transform.Find("Simulation/Engine/Fuel").GetComponents<PlayMakerFSM>()[0];
			startersound = GameObject.Find("CORRIS").transform.Find("Simulation/STARTERxCorris/StarterSound").gameObject;
			//Ambient temperature
			ambienttemp = GameObject.Find("MAP/WEATHER/Clouds").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Randomize 1").Actions[9] as HutongGames.PlayMaker.Actions.FloatClamp;
            if(ToggleWarming.GetValue())
            {
                Warming();
            }
        }
		
		private void Warming()
        {
			SliderWarmingMin.SetVisibility(ToggleWarming.GetValue());
			SliderWarmingMax.SetVisibility(ToggleWarming.GetValue());
			WarmingText.SetVisibility(ToggleWarming.GetValue());
			
			if(Application.loadedLevelName == "GAME")
			{
				ambienttemp.minValue = SliderWarmingMin.GetValue();
				ambienttemp.maxValue = SliderWarmingMax.GetValue();
			}
        }
		
		private void RevLimit()
		{
			SliderRevLimit.SetVisibility(ToggleRevLimit.GetValue());
			
			if(Application.loadedLevelName == "GAME")
			{
				corrisdrivetrain.revLimiter = ToggleRevLimit.GetValue();
				corrisdrivetrain.maxRPM = SliderRevLimit.GetValue();
			}
		}
		
		private void AngleLock()
        {
			SliderAngleLock.SetVisibility(ToggleAngleLock.GetValue());
			AngleLockText.SetVisibility(ToggleAngleLock.GetValue());
			
			if(Application.loadedLevelName == "GAME")
			{
				rackpm.FsmVariables.GetFsmFloat("RackRatio").Value = SliderAngleLock.GetValue();
			}
        }
		
		private void Counter()
		{
			SliderCounter.SetVisibility(ToggleCounter.GetValue());
			CounterText.SetVisibility(ToggleCounter.GetValue());
		}
		
		private void DiffCoef()
		{
			SliderDiff.SetVisibility(ToggleDiff.GetValue());
			DiffText.SetVisibility(ToggleDiff.GetValue());
			
			if(Application.loadedLevelName == "GAME")
			{
				diffpm.FsmVariables.GetFsmFloat("LockCoefficient").Value = SliderDiff.GetValue();
			}
		}
		
        private void Mod_Update()
        {
			//Countersteering
			if(ToggleCounter.GetValue())
			{
				if (corriscontroller.steering == 0)
				{
					slip1 = -corrisrl.slipAngle/SliderCounter.GetValue();
				
					if(-1f < slip1 & slip1 < 1f)
					{
						slip2 = slip1;
					}
					else
					{
						if(slip1 > 1)
						{
							slip2 = 1;
						}
						else
						{
							slip2 = -1;
						}
					}
				
					corrisfl.steering = slip2;
					corrisfr.steering = slip2;
				}
			}
        }
		
		private void Mod_FixedUpdate()
        {
            //Anti overheating
			if(ToggleOverheating.GetValue())
			{
				if(enginetemp.Value >= 90f)
				{
					enginetemp.Value = 85f;
				}
			}
			//Fuel fix
			if(ToggleFuelFix.GetValue())
			{
				if(startersound.activeSelf)
				{
					fuelbool.FsmVariables.GetFsmBool("FuelOK").Value = true;
					fuelgo.SetActive(false);
					waitingstart = true;
				}
			}
			if(waitingstart)
			{
				if(!startersound.activeSelf)
				{
					fuelgo.SetActive(true);
					waitingstart = false;
				}
			}
        }
    }
}
