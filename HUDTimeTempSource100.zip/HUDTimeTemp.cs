﻿using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;

namespace HUDTimeTemp
{
    public class HUDTimeTemp : Mod
    {
        public override string ID => "HUDTimeTemp";
        public override string Name => "HUDTimeTemp";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
        public override string Description => "Shows time and ambient temperature on the HUD.";
        public override Game SupportedGames => Game.MyWinterCar;

        SettingsCheckBox SettingsToggleTime;
		SettingsCheckBox SettingsToggleTemp;
		
		GameObject TimeHud;
		GameObject TempGO;
		GameObject JailGO;
		TextMesh TimeHudTextMesh;
		TextMesh TimeHudTextMeshS;
		bool JailMoved;
		FsmInt hourfsm;
		FsmFloat minutefsm;
		string time;

        public override void ModSetup()
        {
            SetupFunction(Setup.ModSettings, Mod_Settings);
            SetupFunction(Setup.ModSettingsLoaded, Mod_SettingsLoaded);
			SetupFunction(Setup.OnLoad, Mod_OnLoad);
			SetupFunction(Setup.FixedUpdate, Mod_FixedUpdate);
        }

        private void Mod_Settings()
        {
            SettingsToggleTime = Settings.AddCheckBox("settingstoggletime", "Show time", true, ApplySettings);
			SettingsToggleTemp = Settings.AddCheckBox("settingstoggletemp", "Show ambient temperature", true, ApplySettings);
        }

        private void Mod_SettingsLoaded()
        {
            ApplySettings();
        }
		
		private void Mod_OnLoad()
        {
            GameObject HUD = GameObject.Find("GUI/HUD").gameObject;
			GameObject FPSYellow = HUD.transform.Find("FPS/HUDLabel").gameObject;
			TempGO = HUD.transform.Find("Temp").gameObject;
			JailGO = HUD.transform.Find("Jailtime").gameObject;
			
			TempGO.transform.Find("HUDLabel").gameObject.GetComponent<TextMesh>().text = "TEMP";
			TempGO.transform.Find("HUDLabel/HUDLabelShadow").gameObject.GetComponent<TextMesh>().text = "TEMP";
			
			TimeHud = new GameObject();
			TimeHud.name = "TimeHud";
			TimeHud.transform.parent = HUD.transform;
			TimeHud.transform.localPosition = new Vector3(-12.1f, 9.87f, 0f);
			TimeHud.transform.localEulerAngles = Vector3.zero;
			TimeHud.transform.localScale = Vector3.one;
			
			GameObject TimeHudTextGO = GameObject.Instantiate(FPSYellow, Vector3.zero, Quaternion.identity) as GameObject;
			TimeHudTextGO.transform.parent = TimeHud.transform;
			TimeHudTextGO.transform.localPosition = Vector3.zero;
			TimeHudTextGO.transform.localEulerAngles = Vector3.zero;
			TimeHudTextGO.transform.localScale = Vector3.one;
			TimeHudTextMesh = TimeHudTextGO.GetComponent<TextMesh>();
			TimeHudTextMeshS = TimeHudTextGO.transform.GetChild(0).gameObject.GetComponent<TextMesh>();
			TimeHudTextMesh.color = new Color32(255, 255, 255, 255);
			
			hourfsm = FsmVariables.GlobalVariables.FindFsmInt("GlobalHour");
			minutefsm = FsmVariables.GlobalVariables.FindFsmFloat("ClockMinutes");
			
			ApplySettings();
        }

        private void ApplySettings()
        {
            if (Application.loadedLevelName == "GAME")
            { 
                if (SettingsToggleTime.GetValue())
                {
                    TimeHud.SetActive(true);
                }
                else
                {
                    TimeHud.SetActive(false);
                }

                if (SettingsToggleTemp.GetValue())
                {
                    TempGO.SetActive(true);
                    if(!JailMoved)
					{
						JailGO.transform.localPosition = new Vector3(JailGO.transform.localPosition.x, JailGO.transform.localPosition.y - 0.4f, JailGO.transform.localPosition.z);
						JailMoved = true;
					}
                }
                else
                {
                    TempGO.SetActive(false);
				
				    if(JailMoved)
				    {
					    JailGO.transform.localPosition = new Vector3(JailGO.transform.localPosition.x, JailGO.transform.localPosition.y + 0.4f, JailGO.transform.localPosition.z);
					    JailMoved = false;
				    }
                }
            }
        }
		
		private void Mod_FixedUpdate()
        {
            time = hourfsm.Value % 24f + ":" + Mathf.FloorToInt(minutefsm.Value).ToString("00");
			TimeHudTextMesh.text = time;
			TimeHudTextMeshS.text = time;
        }
    }
}
