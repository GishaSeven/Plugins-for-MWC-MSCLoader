﻿using Harmony;
using MSCLoader;
using UnityEngine;
using System.Linq;
using System.Reflection;
using HutongGames.PlayMaker;
using System.Collections;

namespace DriftPack
{
    public class DriftPack : Mod
    {
        public override string ID => "DriftPack";
        public override string Name => "DriftPack";
        public override string Author => "Roman266";
        public override string Version => "1.0.6";
        public override string Description => "Steering angle lock, countersteering, differential locking coefficient, anti overheating, rev limiter, quick engine start, ambient temperature, grip helper, new clutch buttons.";
        public override Game SupportedGames => Game.MyWinterCar;
		
		SettingsCheckBox ToggleWarming;
		SettingsSlider SliderWarmingMin;
		SettingsSlider SliderWarmingMax;
		SettingsText WarmingText;
		SettingsCheckBox ToggleFuelFix;
		SettingsCheckBox ToggleRevLimit;
		SettingsSlider SliderRevLimit;
		SettingsCheckBox ToggleAngleLock;
		SettingsSlider SliderAngleLock;
		SettingsText AngleLockText;
		SettingsCheckBox ToggleCounter;
		SettingsSlider SliderCounter;
		SettingsText CounterText;
		SettingsCheckBox ToggleOverheating;
		SettingsCheckBox ToggleDiff;
		SettingsSlider SliderDiff;
		SettingsText DiffText;
		SettingsCheckBox ToggleGripHelper;
		SettingsSlider SliderGripHelper;
		SettingsText GripHelperText;
		public static SettingsCheckBox ToggleNewClutch;
		SettingsText NewClutchText;
		SettingsKeybind ClutchKeybind1;
		SettingsKeybind ClutchKeybind2;
		GameObject fuelgo;
		PlayMakerFSM fuelbool;
		GameObject startersound;
		PlayMakerArrayListProxy ambienttemplist;
		PlayMakerFSM ambienttemppm;
		HutongGames.PlayMaker.Actions.FloatClamp ambienttemp;
		HutongGames.PlayMaker.Actions.FloatClamp ambienttemp2;
		FsmFloat ambienttemp3;
		FsmFloat ambienttemp4;
		bool waitingstart;
		GameObject revlimitergo;
		PlayMakerFSM revlimiterpm;
		PlayMakerFSM rackpm;
		public static AxisCarController corriscontroller;
		Wheel corrisfl;
		Wheel corrisfr;
		Wheel corrisrl;
		GameObject corrisgo;
		float slip1;
		float slip2;
		FsmFloat enginetemp;
		PlayMakerFSM diffpm;
		HutongGames.PlayMaker.Actions.SetFloatValue gripvalue0;
		HutongGames.PlayMaker.Actions.FloatOperator gripvalue1;
		FsmFloat griphelp;
		public static float clutchInput;
        public static GameObject player;
		Drivetrain corrisdrivetrain;
		bool NewClutchBool;
		bool NewClutchBoolUpd;
		
        public override void ModSetup()
        {
            SetupFunction(Setup.ModSettings, Mod_Settings);
			SetupFunction(Setup.ModSettingsLoaded, Mod_SettingsLoaded);
			SetupFunction(Setup.OnLoad, Mod_OnLoad);
            SetupFunction(Setup.Update, Mod_Update);
			SetupFunction(Setup.FixedUpdate, Mod_FixedUpdate);
        }
		
        private void Mod_Settings()
        {
            ToggleAngleLock = Settings.AddCheckBox("toggleanglelock", "Steering angle lock", true, AngleLock);
			SliderAngleLock = Settings.AddSlider("slideranglelock", "Max angle", 20f, 60f, 45f, AngleLock);
			AngleLockText = Settings.AddText("Original game values: 26 degrees for 'Steering rack 26' and 33 degrees for 'Steering rack 33'. Disable 'Steering help' or set 'Steer angle limiter' to 0 in game settings to get changes while the car is moving.");
			ToggleCounter = Settings.AddCheckBox("togglecounter", "Countersteering", true, Counter);
			SliderCounter = Settings.AddSlider("slidercounter", "Demultiplier", 1f, 100f, 30f, Counter);
			CounterText = Settings.AddText("If you do not press the steering left or right button, the wheels will turn in the direction of the skid on their own, this is how properly built IRL drift cars work. You can change how much the wheels will turn depending on the strength of the skid. For this feature to work, disable 'Steering help' in game settings.");
			ToggleDiff = Settings.AddCheckBox("togglediff", "Differential locking coefficient", true, DiffCoef);
			SliderDiff = Settings.AddSlider("sliderdiff", "Coefficient", 0f, 100f, 100f, DiffCoef);
			DiffText = Settings.AddText("Original game values: 0 for open rear axle and 49 for LSD rear axle.");
			ToggleOverheating = Settings.AddCheckBox("toggleoverheating", "Anti overheating", true);
			ToggleRevLimit = Settings.AddCheckBox("togglerevlimit", "Rev limiter", false, RevLimit);
			SliderRevLimit = Settings.AddSlider("sliderrevlimit", "Max RPM", 1000f, 12000f, 8000f, RevLimit);
			ToggleFuelFix = Settings.AddCheckBox("togglefuel", "Ignoring fuel problems while cranking (quick engine start)", true);
			ToggleWarming = Settings.AddCheckBox("togglewarming", "Ambient temperature", true, Warming);
			SliderWarmingMin = Settings.AddSlider("sliderwarmingmin", "Min ambient temperature", -100f, 100f, 5f, Warming);
			SliderWarmingMax = Settings.AddSlider("sliderwarmingmax", "Max ambient temperature", -100f, 100f, 10f, Warming);
			WarmingText = Settings.AddText("Original game values: -47.3 and -1.21 degrees Celsius. My values ​​are intended to defrost the car windows and prevent the player from shaking from the cold.");
			ToggleGripHelper = Settings.AddCheckBox("togglegriphelper", "Grip helper", true, GripHelper);
			SliderGripHelper = Settings.AddSlider("slidergriphelper", "Plus value", 0f, 1f, 0.3f, GripHelper);
			GripHelperText = Settings.AddText("Original game values: 0 if you are not using 'Steering help' or if 'Corris grip helper' set to 0 in game settings; 0.3 if you are using 'Steering help' and 'Corris grip helper' set to 100 in game settings.");
			ToggleNewClutch = Settings.AddCheckBox("togglenewclutch", "Replace one old clutch button with new twos", false, NewClutch);
			NewClutchText = Settings.AddText("Adds two new clutch buttons to replace the old one. The idea is that one clutch button is used as usual, the second is assigned to the same key as the handbrake to prevent the engine from stalling. Button presses are not displayed in 'Controls debug'.");
			
			ClutchKeybind1 = Keybind.Add("newclutchkey1", "New clutch key 1", KeyCode.X);
			ClutchKeybind2 = Keybind.Add("newclutchkey2", "New clutch key 2", KeyCode.Space);
        }
		
		private void Mod_SettingsLoaded()
        {
            AngleLock();
			Counter();
			RevLimit();
			Warming();
			DiffCoef();
			GripHelper();
			NewClutch();
        }
		
		private void Mod_OnLoad()
        {
            try
			{
				corrisgo = GameObject.Find("CORRIS").gameObject;
			}
			catch 
			{
				ModConsole.Error("DriftPack can't find Corris");
			}
            
			//Angle lock
            try
			{
				rackpm = corrisgo.transform.FindChild("PhysicalAssemblies/FRONT/AxleFront/VINP_SteeringRack").gameObject.GetComponent<PlayMakerFSM>();
			
				if(ToggleAngleLock.GetValue())
				{
					AngleLock();
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't find steering rack");
			}
			
			//Countersteering
			try
			{
				corriscontroller = corrisgo.GetComponent<AxisCarController>();
				corrisfl = corrisgo.transform.Find("PhysicalAssemblies/FRONT/AxleFront/LinkFL/ToeFL/DamagePivotFL/WHEELc_FL").gameObject.GetComponent<Wheel>();
				corrisfr = corrisgo.transform.Find("PhysicalAssemblies/FRONT/AxleFront/LinkFR/ToeFR/DamagePivotFR/WHEELc_FR").gameObject.GetComponent<Wheel>();
				corrisrl = corrisgo.transform.Find("PhysicalAssemblies/REAR/AxleDamagePivot/RearWheelsStatic/WHEELc_RL").gameObject.GetComponent<Wheel>();
			}
			catch 
			{
				ToggleCounter.SetValue(false);
				ModConsole.Error("DriftPack can't find wheels, countersteering disabled");
			}
			
			//Differential coefficient
			try
			{
				diffpm = corrisgo.transform.FindChild("Simulation/Systems/Drivetrain").gameObject.GetComponents<PlayMakerFSM>()[0];
            
				if (ToggleDiff.GetValue())
				{
					DiffCoef();
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't find differential");
			}
			
            //Anti overheating
			try
			{
				enginetemp = FsmVariables.GlobalVariables.FindFsmFloat("EngineTemp");
				float test = enginetemp.Value;
			}
			catch 
			{
				ToggleOverheating.SetValue(false);
				ModConsole.Error("DriftPack can't find engine temperature, anti overheating disabled");
			}
            
			//Rev limiter
			try
			{
				revlimitergo = corrisgo.transform.FindChild("Assemblies/VINP_Revlimiter").gameObject;
				revlimiterpm = revlimitergo.GetComponent<PlayMakerFSM>();
			
				if(ToggleRevLimit.GetValue())
				{
					RevLimit();
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't find rev limiter");
			}
			
			//Fuel fix
			try
			{
				fuelgo = corrisgo.transform.Find("Simulation/Engine/Fuel").gameObject;
				fuelbool = corrisgo.transform.Find("Simulation/Engine/Fuel").GetComponents<PlayMakerFSM>()[0];
				startersound = corrisgo.transform.Find("Simulation/STARTERxCorris/StarterSound").gameObject;
			}
			catch 
			{
				ToggleFuelFix.SetValue(false);
				ModConsole.Error("DriftPack can't find fuel, fuel fix disabled");
			}
			
			//Ambient temperature
			try
			{
				ambienttemplist = GameObject.Find("MAP/WEATHER/Forecast").GetComponents<PlayMakerArrayListProxy>()[0];
				ambienttemppm = GameObject.Find("MAP/WEATHER/Forecast").GetComponent<PlayMakerFSM>();
				ambienttemp = ambienttemppm.FsmStates.FirstOrDefault(state => state.Name == "Fudge").Actions[6] as HutongGames.PlayMaker.Actions.FloatClamp;
				ambienttemp2 = ambienttemppm.FsmStates.FirstOrDefault(state => state.Name == "Create new week").Actions[3] as HutongGames.PlayMaker.Actions.FloatClamp;
				ambienttemp3 = ambienttemppm.FsmVariables.GetFsmFloat("OldTemp");
				ambienttemp4 = ambienttemppm.FsmVariables.GetFsmFloat("NewTemp");
            
				if(ToggleWarming.GetValue())
				{
					Warming();
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't find ambient temperature");
			}
			
			//Grip helper
			try
			{
				gripvalue0 = GameObject.Find("Systems/OptionsDB").gameObject.GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Grip helper").Actions[0] as HutongGames.PlayMaker.Actions.SetFloatValue;
				gripvalue1 = GameObject.Find("Systems/OptionsDB").gameObject.GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Grip helper").Actions[2] as HutongGames.PlayMaker.Actions.FloatOperator;
				griphelp = FsmVariables.GlobalVariables.FindFsmFloat("OptionsGripHelper");
			
				if(ToggleGripHelper.GetValue())
				{
					GripHelper();
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't find grip helper");
			}
			
			//New clutch buttons
			try
			{
				corrisdrivetrain = corrisgo.GetComponent<Drivetrain>();
				player = GameObject.Find("PLAYER").gameObject;
				clutchInput = 0;
			
				if(ToggleNewClutch.GetValue())
				{
					NewClutch();
				}
			}
			catch 
			{
				ToggleNewClutch.SetValue(false);
				ModConsole.Error("DriftPack can't find drivetrain, new clutch buttons disabled");
			}
        }
		
		private void Warming()
        {
			try
			{
				SliderWarmingMin.SetVisibility(ToggleWarming.GetValue());
				SliderWarmingMax.SetVisibility(ToggleWarming.GetValue());
				WarmingText.SetVisibility(ToggleWarming.GetValue());
			
				if(Application.loadedLevelName == "GAME")
				{
					ArrayList weekly = new ArrayList();
					weekly.AddRange(new string[] { "0", SliderWarmingMin.GetValue().ToString(), SliderWarmingMax.GetValue().ToString(), SliderWarmingMin.GetValue().ToString(), SliderWarmingMax.GetValue().ToString(), SliderWarmingMin.GetValue().ToString(), SliderWarmingMax.GetValue().ToString(), SliderWarmingMin.GetValue().ToString() });
					ambienttemplist._arrayList = weekly;
				
					ambienttemp.minValue = SliderWarmingMin.GetValue();
					ambienttemp.maxValue = SliderWarmingMax.GetValue();
					ambienttemp2.minValue = SliderWarmingMin.GetValue();
					ambienttemp2.maxValue = SliderWarmingMax.GetValue();
					ambienttemp3.Value = SliderWarmingMin.GetValue();
					ambienttemp4.Value = SliderWarmingMax.GetValue();
					ambienttemppm.SendEvent("FINISHED");
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't apply ambient temperature");
			}
        }
		
		private void RevLimit()
		{
			try
			{
				SliderRevLimit.SetVisibility(ToggleRevLimit.GetValue());
			
				if(Application.loadedLevelName == "GAME")
				{
					revlimiterpm.FsmVariables.GetFsmFloat("SettingRPM").Value = SliderRevLimit.GetValue();
				
					if(revlimitergo.transform.childCount == 0)
					{
						revlimiterpm.FsmVariables.GetFsmBool("Installed").Value = ToggleRevLimit.GetValue();
					}
					else
					{
						if(!ToggleRevLimit.GetValue())
						{
							revlimiterpm.FsmVariables.GetFsmFloat("SettingRPM").Value = revlimitergo.transform.GetChild(0).gameObject.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("SettingRPM").Value;
						}
					}
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't apply rev limiter");
			}
		}
		
		private void AngleLock()
        {
			try
			{
				SliderAngleLock.SetVisibility(ToggleAngleLock.GetValue());
				AngleLockText.SetVisibility(ToggleAngleLock.GetValue());
			
				if(Application.loadedLevelName == "GAME")
				{
					rackpm.FsmVariables.GetFsmFloat("RackRatio").Value = SliderAngleLock.GetValue();
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't apply angle lock");
			}
        }
		
		private void Counter()
		{
			SliderCounter.SetVisibility(ToggleCounter.GetValue());
			CounterText.SetVisibility(ToggleCounter.GetValue());
		}
		
		private void DiffCoef()
		{
			try
			{
				SliderDiff.SetVisibility(ToggleDiff.GetValue());
				DiffText.SetVisibility(ToggleDiff.GetValue());
			
				if(Application.loadedLevelName == "GAME")
				{
					diffpm.FsmVariables.GetFsmFloat("LockCoefficient").Value = SliderDiff.GetValue();
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't apply differential");
			}
		}
		
		private void GripHelper()
        {
			try
			{
				SliderGripHelper.SetVisibility(ToggleGripHelper.GetValue());
				GripHelperText.SetVisibility(ToggleGripHelper.GetValue());
			
				if(Application.loadedLevelName == "GAME")
				{
					gripvalue0.floatValue = SliderGripHelper.GetValue();
					gripvalue0.floatVariable = SliderGripHelper.GetValue();
					gripvalue1.float1 = SliderGripHelper.GetValue();
					gripvalue1.storeResult = SliderGripHelper.GetValue();
					griphelp.Value = SliderGripHelper.GetValue();
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't apply grip helper");
			}
        }
		
		private void NewClutch()
		{
			try
			{
				NewClutchText.SetVisibility(ToggleNewClutch.GetValue());
			
				if(Application.loadedLevelName == "GAME")
				{
					if(!NewClutchBool)
					{
						var harmony = HarmonyInstance.Create("NewClutchButtons");
						harmony.PatchAll(Assembly.GetExecutingAssembly());
					
						NewClutchBool = true;
					}
				}
			}
			catch 
			{
				ModConsole.Error("DriftPack can't apply clutch buttons");
			}
		}
		
        private void Mod_Update()
        {
			//Countersteering
			if(ToggleCounter.GetValue())
			{
				if (corriscontroller.steering == 0)
				{
					slip1 = -corrisrl.slipAngle/SliderCounter.GetValue();
				
					if(-1f < slip1 & slip1 < 1f)
					{
						slip2 = slip1;
					}
					else
					{
						if(slip1 > 1)
						{
							slip2 = 1;
						}
						else
						{
							slip2 = -1;
						}
					}
				
					corrisfl.steering = slip2;
					corrisfr.steering = slip2;
				}
			}
			//New clutch buttons
			if(ToggleNewClutch.GetValue())
			{
				if(ClutchKeybind1.GetKeybind() || ClutchKeybind2.GetKeybind() || corriscontroller.brakeKey && corrisdrivetrain.autoClutch)
				{
					clutchInput = 1;
					NewClutchBoolUpd = true;
				}
				else
				{
					if(NewClutchBoolUpd)
					{
						clutchInput = 0;
						NewClutchBoolUpd = false;
                    }
				}
			}
        }
		
		private void Mod_FixedUpdate()
        {
            //Anti overheating
			if(ToggleOverheating.GetValue())
			{
				if(enginetemp.Value >= 90f)
				{
					enginetemp.Value = 85f;
				}
			}
			//Fuel fix
			if(ToggleFuelFix.GetValue())
			{
				if(startersound.activeSelf)
				{
					fuelbool.FsmVariables.GetFsmBool("FuelOK").Value = true;
					fuelgo.SetActive(false);
					waitingstart = true;
				}
			}
			if(waitingstart)
			{
				if(!startersound.activeSelf)
				{
					fuelgo.SetActive(true);
					waitingstart = false;
				}
			}
        }
    }
	
	[HarmonyPatch(typeof(CarController))]
    [HarmonyPatch("Update")]
    class CarController_Update_Patch
    {
        static void Postfix()
        {
			if(DriftPack.ToggleNewClutch.GetValue() && DriftPack.player.transform.root.gameObject.name == "CORRIS")
			{
				DriftPack.corriscontroller.clutchInput = DriftPack.clutchInput;
			}
        }
    }
}
