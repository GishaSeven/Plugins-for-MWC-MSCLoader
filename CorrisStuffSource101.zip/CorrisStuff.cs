﻿using MSCLoader;
using UnityEngine;
using System.Linq;

namespace CorrisStuff
{
    public class CorrisStuff : Mod
    {
        public override string ID => "CorrisStuff";
        public override string Name => "CorrisStuff";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";
        public override string Description => "Various stuff for Corris.";
        public override Game SupportedGames => Game.MyWinterCar;
		
		SettingsText DisclaimerText;
		SettingsCheckBox FendersToggle;
		SettingsDropDownList HeadlightsDropDownList;
		SettingsCheckBox BumpersToggle;
		SettingsCheckBox BootlidToggle;
		SettingsCheckBox RegplateToggle;
		SettingsCheckBox RadioToggle;
		SettingsCheckBox AntennaToggle;
		SettingsCheckBox ShelfToggle;
		SettingsCheckBox CDToggle;
		SettingsCheckBox HoodToggle;
		SettingsCheckBox SeatbeltToggle;
		SettingsCheckBox KeychainToggle;
		SettingsCheckBox SunvisorsToggle;
		
		Mesh antenna;
		
        public override void ModSetup()
        {
            SetupFunction(Setup.OnLoad, Mod_OnLoad);
			SetupFunction(Setup.ModSettings, Mod_Settings);
        }

        private void Mod_Settings()
        {
            DisclaimerText = Settings.AddText("After making changes, exit the game and delete meshsave.txt file!");
			FendersToggle = Settings.AddCheckBox("togglefenders", "Real style front fenders", true);
			string[] HeadlightsStrings = new string[] { "Default", "Round without turn signal", "Square" };
            HeadlightsDropDownList = Settings.AddDropDownList("headlightlist", "Headlights", HeadlightsStrings, 2);
			BumpersToggle = Settings.AddCheckBox("togglebumpers", "Flat front bumpers (also changes the GT bumper)", true);
			BootlidToggle = Settings.AddCheckBox("togglebootlid", "Bigger black trim for LX/SLX bootlid", true);
			RegplateToggle = Settings.AddCheckBox("toggleregplate", "Even arrangement of register plates", true);
			RadioToggle = Settings.AddCheckBox("toggleradio", "Noise free radio without antennas", false);
			AntennaToggle = Settings.AddCheckBox("toggleantenna", "Add a decorative antenna to front right fender", false);
			ShelfToggle = Settings.AddCheckBox("toggleshelf", "New subwoofer parcel shelf", true);
			CDToggle = Settings.AddCheckBox("togglecd", "Increase size of installed CD player", false);
			HoodToggle = Settings.AddCheckBox("togglehood", "Corris lettering on hood", false);
			SeatbeltToggle = Settings.AddCheckBox("toggleseat", "Add passenger seat belt", false);
			KeychainToggle = Settings.AddCheckBox("togglekeychain", "Add keychain", true);
			SunvisorsToggle = Settings.AddCheckBox("togglesunvisors", "Add sunvisors", false);
        }
		
        private void Mod_OnLoad()
        {
            GameObject CorrisGO = GameObject.Find("CORRIS");
			//AssetBundle bundle = LoadAssets.LoadBundle(this, "stuff.unity3d");
			AssetBundle bundle = LoadAssets.LoadBundle("CorrisStuff.Assets.stuff.unity3d");
			Material ATLAS_MOTOR = Resources.FindObjectsOfTypeAll<Material>().FirstOrDefault(g => g.name == "ATLAS_MOTOR_MWC");
			Material[] ATLAS_MOTOR2 = new Material[1] { ATLAS_MOTOR };
			GameObject LeftIndicator = CorrisGO.transform.Find("Simulation/Electricity/PowerON/Indicators/Left/FrontLeftIndicator").gameObject;
			GameObject LeftIndicator2 = LeftIndicator.transform.Find("indicator_FL").gameObject;
			GameObject RightIndicator = CorrisGO.transform.Find("Simulation/Electricity/PowerON/Indicators/Right/FrontRightIndicator").gameObject;
			GameObject RightIndicator2 = RightIndicator.transform.Find("indicator_RL").gameObject;
			
			if(AntennaToggle.GetValue())
			{
				GameObject bundleantenna = Object.Instantiate(bundle.LoadAsset<GameObject>("antenna.prefab"));
				antenna = bundleantenna.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleantenna);
			}
			
			if(FendersToggle.GetValue())
			{
				GameObject bundlefenderl = Object.Instantiate(bundle.LoadAsset<GameObject>("body_fender_l.prefab"));
				GameObject bundlefenderr = Object.Instantiate(bundle.LoadAsset<GameObject>("body_fender_r.prefab"));
				GameObject bundleindicatorl = Object.Instantiate(bundle.LoadAsset<GameObject>("headlight_indicator_l.prefab"));
				GameObject bundleindicatorr = Object.Instantiate(bundle.LoadAsset<GameObject>("headlight_indicator_r.prefab"));
				Mesh fenderl = bundlefenderl.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlefenderl);
				Mesh fenderr = bundlefenderr.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlefenderr);
				Mesh indicatorl = bundleindicatorl.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleindicatorl);
				Mesh indicatorr = bundleindicatorr.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleindicatorr);
				
				foreach (GameObject fender in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Fender(VINXX)"))
				{
					if (fender.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_fender_l"))
					{
						fender.GetComponent<MeshFilter>().sharedMesh = fenderl;
					}

					if (fender.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_fender_r"))
					{
						fender.GetComponent<MeshFilter>().sharedMesh = fenderr;
					}
					
					if (fender.GetComponent<MeshRenderer>().materials.Length == 2)
					{
						Material[] oldMats = fender.GetComponent<MeshRenderer>().materials;
						Material[] newMats = new Material[oldMats.Length + 1];
						oldMats.CopyTo(newMats, 0);
						ATLAS_MOTOR2.CopyTo(newMats, 2);
						fender.GetComponent<MeshRenderer>().materials = newMats;
					}
					
					if(AntennaToggle.GetValue() && fender.GetComponents<PlayMakerFSM>()[0].FsmVariables.GetFsmString("ID").Value.Contains("VIN409"))
					{
						GameObject antennago = new GameObject();
						antennago.AddComponent<MeshFilter>().mesh = antenna;
						antennago.AddComponent<MeshRenderer>().material = ATLAS_MOTOR;
						antennago.transform.parent = fender.transform;
						antennago.transform.localPosition = Vector3.zero;
						antennago.transform.localEulerAngles = Vector3.zero;
						antennago.transform.localScale = Vector3.one;
					}
                }
			
				GameObject PrefabL = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN410").gameObject;
				PrefabL.GetComponent<MeshFilter>().sharedMesh = fenderl;
				if(PrefabL.GetComponent<MeshRenderer>().materials.Length == 2)
				{
					Material[] oldMatsL = PrefabL.GetComponent<MeshRenderer>().materials;
					Material[] newMatsL = new Material[oldMatsL.Length + 1];
					oldMatsL.CopyTo(newMatsL, 0);
					ATLAS_MOTOR2.CopyTo(newMatsL, 2);
					PrefabL.GetComponent<MeshRenderer>().materials = newMatsL;
				}
				
				GameObject PrefabR = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN409").gameObject;
				PrefabR.GetComponent<MeshFilter>().sharedMesh = fenderr;
				if(PrefabR.GetComponent<MeshRenderer>().materials.Length == 2)
				{
					Material[] oldMatsR = PrefabR.GetComponent<MeshRenderer>().materials;
					Material[] newMatsR = new Material[oldMatsR.Length + 1];
					oldMatsR.CopyTo(newMatsR, 0);
					ATLAS_MOTOR2.CopyTo(newMatsR, 2);
					PrefabR.GetComponent<MeshRenderer>().materials = newMatsR;
				}
				
				if(AntennaToggle.GetValue())
				{
					GameObject antennago = new GameObject();
					antennago.AddComponent<MeshFilter>().mesh = antenna;
					antennago.AddComponent<MeshRenderer>().material = ATLAS_MOTOR;
					antennago.transform.parent = PrefabR.transform;
					antennago.transform.localPosition = Vector3.zero;
					antennago.transform.localEulerAngles = Vector3.zero;
					antennago.transform.localScale = Vector3.one;
				}
			
				LeftIndicator.transform.localPosition = new Vector3 (-0.74f, 0.256f, 1.995f);
				LeftIndicator2.transform.localPosition = new Vector3 (0.006f, 0f, -0.063f);
				LeftIndicator2.GetComponent<MeshFilter>().sharedMesh = indicatorl;
			
				RightIndicator.transform.localPosition = new Vector3 (0.74f, 0.256f, 1.995f);
				RightIndicator2.transform.localPosition = new Vector3 (-0.006f, 0f, -0.063f);
				RightIndicator2.GetComponent<MeshFilter>().sharedMesh = indicatorl;
				
				HutongGames.PlayMaker.Actions.SetProperty FenderLFSM = CorrisGO.transform.Find("Assemblies/VINP_FenderLeft").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				FenderLFSM.targetProperty.ObjectParameter = fenderl;
				HutongGames.PlayMaker.Actions.SetProperty FenderRFSM = CorrisGO.transform.Find("Assemblies/VINP_FenderRight").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				FenderRFSM.targetProperty.ObjectParameter = fenderr;
			}
			else
			{
				if(AntennaToggle.GetValue())
				{
					foreach (GameObject fender in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Fender(VINXX)" && g.GetComponents<PlayMakerFSM>()[0].FsmVariables.GetFsmString("ID").Value.Contains("VIN409")))
					{
						GameObject antennago2 = new GameObject();
						antennago2.AddComponent<MeshFilter>().mesh = antenna;
						antennago2.AddComponent<MeshRenderer>().material = ATLAS_MOTOR;
						antennago2.transform.parent = fender.transform;
						antennago2.transform.localPosition = Vector3.zero;
						antennago2.transform.localEulerAngles = Vector3.zero;
						antennago2.transform.localScale = Vector3.one;
					}
					
					GameObject PrefabR = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN409").gameObject;
					GameObject antennago = new GameObject();
					antennago.AddComponent<MeshFilter>().mesh = antenna;
					antennago.AddComponent<MeshRenderer>().material = ATLAS_MOTOR;
					antennago.transform.parent = PrefabR.transform;
					antennago.transform.localPosition = Vector3.zero;
					antennago.transform.localEulerAngles = Vector3.zero;
					antennago.transform.localScale = Vector3.one;
				}
			}
			
			if(HeadlightsDropDownList.GetSelectedItemIndex() == 1)
			{
				GameObject bundleheadlight = Object.Instantiate(bundle.LoadAsset<GameObject>("headlight_frame.prefab"));
				Mesh headlight = bundleheadlight.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleheadlight);
				GameObject bundlegrillel = Object.Instantiate(bundle.LoadAsset<GameObject>("body_grille4.prefab"));
				Mesh grillel = bundlegrillel.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillel);
				GameObject bundlegrillelx = Object.Instantiate(bundle.LoadAsset<GameObject>("body_grille.prefab"));
				Mesh grillelx = bundlegrillelx.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillelx);
				GameObject bundlegrilleslx = Object.Instantiate(bundle.LoadAsset<GameObject>("body_grille3.prefab"));
				Mesh grilleslx = bundlegrilleslx.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrilleslx);
				GameObject bundlegrillegt = Object.Instantiate(bundle.LoadAsset<GameObject>("body_grille5.prefab"));
				Mesh grillegt = bundlegrillegt.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillegt);
				GameObject bundlewiringl = Object.Instantiate(bundle.LoadAsset<GameObject>("wiring_headlightleft.prefab"));
				Mesh wiringl = bundlewiringl.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlewiringl);
				GameObject bundlewiringr = Object.Instantiate(bundle.LoadAsset<GameObject>("wiring_headlightright.prefab"));
				Mesh wiringr = bundlewiringr.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlewiringr);
			
				foreach (GameObject headlights in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Head Light Assembly(VINXX)"))
				{
					headlights.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN401").gameObject.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN402").gameObject.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				
				foreach (GameObject grille in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Grille(VINXX)"))
				{
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille4"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grillel;
					}
					
					if (grille.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("ID").Value.Contains("VIN413B"))
					{
						if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille"))
						{
							grille.GetComponent<MeshFilter>().sharedMesh = grillelx;
						}
					}
					
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille3"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grilleslx;
					}
					
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille5"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grillegt;
					}
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413").gameObject.GetComponent<MeshFilter>().sharedMesh = grillel;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413B").gameObject.GetComponent<MeshFilter>().sharedMesh = grillelx;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413C").gameObject.GetComponent<MeshFilter>().sharedMesh = grilleslx;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413D").gameObject.GetComponent<MeshFilter>().sharedMesh = grillegt;
				
				CorrisGO.transform.Find("Wiring/Parts/connector-headlightleft").gameObject.GetComponent<MeshFilter>().sharedMesh = wiringl;
				CorrisGO.transform.Find("Wiring/Parts/connector-headlightright").gameObject.GetComponent<MeshFilter>().sharedMesh = wiringr;
				
				if(!FendersToggle.GetValue())
				{
					LeftIndicator.GetComponent<Light>().enabled = false;
					LeftIndicator2.GetComponent<MeshRenderer>().enabled = false;
					RightIndicator.GetComponent<Light>().enabled = false;
					RightIndicator2.GetComponent<MeshRenderer>().enabled = false;
				}
				
				HutongGames.PlayMaker.Actions.SetProperty GrilleLFSM = CorrisGO.transform.Find("Assemblies/VINP_Grille").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 4").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				GrilleLFSM.targetProperty.ObjectParameter = grillel;
				HutongGames.PlayMaker.Actions.SetProperty GrilleLXFSM = CorrisGO.transform.Find("Assemblies/VINP_Grille").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 2").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				GrilleLXFSM.targetProperty.ObjectParameter = grillelx;
				HutongGames.PlayMaker.Actions.SetProperty GrilleSLXFSM = CorrisGO.transform.Find("Assemblies/VINP_Grille").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 3").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				GrilleSLXFSM.targetProperty.ObjectParameter = grilleslx;
				HutongGames.PlayMaker.Actions.SetProperty GrilleGTFSM = CorrisGO.transform.Find("Assemblies/VINP_Grille").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 5").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				GrilleGTFSM.targetProperty.ObjectParameter = grillegt;
			}
			
			if(HeadlightsDropDownList.GetSelectedItemIndex() == 2)
			{
				GameObject bundleheadlight = Object.Instantiate(bundle.LoadAsset<GameObject>("square_headlight_frame.prefab"));
				Mesh headlight = bundleheadlight.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleheadlight);
				GameObject bundleheadlightglass = Object.Instantiate(bundle.LoadAsset<GameObject>("square_headlight_glass.prefab"));
				Mesh headlightglass = bundleheadlightglass.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleheadlightglass);
				GameObject bundlegrillel = Object.Instantiate(bundle.LoadAsset<GameObject>("square_body_grille4.prefab"));
				Mesh grillel = bundlegrillel.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillel);
				GameObject bundlegrillelx = Object.Instantiate(bundle.LoadAsset<GameObject>("square_body_grille.prefab"));
				Mesh grillelx = bundlegrillelx.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillelx);
				GameObject bundlegrilleslx = Object.Instantiate(bundle.LoadAsset<GameObject>("square_body_grille3.prefab"));
				Mesh grilleslx = bundlegrilleslx.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrilleslx);
				GameObject bundlegrillegt = Object.Instantiate(bundle.LoadAsset<GameObject>("square_body_grille5.prefab"));
				Mesh grillegt = bundlegrillegt.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlegrillegt);
				GameObject bundlewiringl = Object.Instantiate(bundle.LoadAsset<GameObject>("square_wiring_headlightleft.prefab"));
				Mesh wiringl = bundlewiringl.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlewiringl);
				GameObject bundlewiringr = Object.Instantiate(bundle.LoadAsset<GameObject>("square_wiring_headlightright.prefab"));
				Mesh wiringr = bundlewiringr.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlewiringr);
			
				foreach (GameObject headlights in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Head Light Assembly(VINXX)"))
				{
					headlights.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
					headlights.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
					headlights.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshRenderer>().material.color = new Color32(157,157,157,255);

                    if (headlights.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("ID").Value.Contains("VIN401"))
					{
						headlights.transform.Find("Bolts").transform.GetChild(1).transform.localPosition = new Vector3 (0.212f, 0.0272f, 0.0044f);
						headlights.transform.Find("Trigger_Lightbulb").transform.localPosition = new Vector3 (0.051f, 0f, 0.001f);
					}
					
					if (headlights.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("ID").Value.Contains("VIN402"))
					{
						headlights.transform.Find("Bolts").transform.GetChild(0).transform.localPosition = new Vector3 (-0.212f, 0.0272f, 0.0044f);
						headlights.transform.Find("Trigger_Lightbulb").transform.localPosition = new Vector3 (-0.051f, 0f, 0.001f);
					}
				}
				
				GameObject PrefabLeft = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN401");
				PrefabLeft.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				PrefabLeft.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				PrefabLeft.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshRenderer>().material.color = new Color32(157,157,157,255);
				PrefabLeft.transform.Find("Bolts").transform.GetChild(1).transform.localPosition = new Vector3 (0.212f, 0.0272f, 0.0044f);
				PrefabLeft.transform.Find("Trigger_Lightbulb").transform.localPosition = new Vector3 (0.051f, 0f, 0.001f);
				GameObject PrefabRight = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN402");
				PrefabRight.transform.Find("ScaleMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = headlight;
				PrefabRight.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				PrefabRight.transform.Find("ScaleMesh/glass").gameObject.GetComponent<MeshRenderer>().material.color = new Color32(157,157,157,255);
				PrefabRight.transform.Find("Bolts").transform.GetChild(0).transform.localPosition = new Vector3 (-0.212f, 0.0272f, 0.0044f);
				PrefabRight.transform.Find("Trigger_Lightbulb").transform.localPosition = new Vector3 (-0.051f, 0f, 0.001f);
				
				CorrisGO.transform.Find("Simulation/Electricity/PowerON/BeamsShort/BeamShortLeft/headlight_FL").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				CorrisGO.transform.Find("Simulation/Electricity/PowerON/BeamsShort/BeamShortRight/headlight_RL").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				CorrisGO.transform.Find("Simulation/Electricity/PowerON/BeamsLong/BeamLongLeft/headlight_FL").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				CorrisGO.transform.Find("Simulation/Electricity/PowerON/BeamsLong/BeamLongRight/headlight_RL").gameObject.GetComponent<MeshFilter>().sharedMesh = headlightglass;
				
				foreach (GameObject grille in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Grille(VINXX)"))
				{
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille4"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grillel;
					}
					
					if (grille.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("ID").Value.Contains("VIN413B"))
					{
						if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille"))
						{
							grille.GetComponent<MeshFilter>().sharedMesh = grillelx;
						}
					}
					
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille3"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grilleslx;
					}
					
					if (grille.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_grille5"))
					{
						grille.GetComponent<MeshFilter>().sharedMesh = grillegt;
					}
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413").gameObject.GetComponent<MeshFilter>().sharedMesh = grillel;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413B").gameObject.GetComponent<MeshFilter>().sharedMesh = grillelx;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413C").gameObject.GetComponent<MeshFilter>().sharedMesh = grilleslx;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN413D").gameObject.GetComponent<MeshFilter>().sharedMesh = grillegt;
				
				CorrisGO.transform.Find("Wiring/Parts/connector-headlightleft").gameObject.GetComponent<MeshFilter>().sharedMesh = wiringl;
				CorrisGO.transform.Find("Wiring/Parts/connector-headlightright").gameObject.GetComponent<MeshFilter>().sharedMesh = wiringr;
				
				if(!FendersToggle.GetValue())
				{
					LeftIndicator.GetComponent<Light>().enabled = false;
					LeftIndicator2.GetComponent<MeshRenderer>().enabled = false;
					RightIndicator.GetComponent<Light>().enabled = false;
					RightIndicator2.GetComponent<MeshRenderer>().enabled = false;
				}
				
				HutongGames.PlayMaker.Actions.SetProperty GrilleLFSM = CorrisGO.transform.Find("Assemblies/VINP_Grille").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 4").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				GrilleLFSM.targetProperty.ObjectParameter = grillel;
				HutongGames.PlayMaker.Actions.SetProperty GrilleLXFSM = CorrisGO.transform.Find("Assemblies/VINP_Grille").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 2").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				GrilleLXFSM.targetProperty.ObjectParameter = grillelx;
				HutongGames.PlayMaker.Actions.SetProperty GrilleSLXFSM = CorrisGO.transform.Find("Assemblies/VINP_Grille").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 3").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				GrilleSLXFSM.targetProperty.ObjectParameter = grilleslx;
				HutongGames.PlayMaker.Actions.SetProperty GrilleGTFSM = CorrisGO.transform.Find("Assemblies/VINP_Grille").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 5").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				GrilleGTFSM.targetProperty.ObjectParameter = grillegt;
			}
			
			if(BumpersToggle.GetValue())
			{
				GameObject bundlebumper1 = Object.Instantiate(bundle.LoadAsset<GameObject>("body_bumper_f.prefab"));
				Mesh bumper1 = bundlebumper1.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlebumper1);
				GameObject bundlebumper2 = Object.Instantiate(bundle.LoadAsset<GameObject>("body_bumper_f2.prefab"));
				Mesh bumper2 = bundlebumper2.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlebumper2);
				GameObject bundlebumper3 = Object.Instantiate(bundle.LoadAsset<GameObject>("body_bumper_f3.prefab"));
				Mesh bumper3 = bundlebumper3.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlebumper3);
				
				foreach (GameObject bumper in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Bumper(VINXX)"))
				{
					if (bumper.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Code").Value.Contains("A"))
					{
						if (bumper.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bumper_f"))
						{
							bumper.GetComponent<MeshFilter>().sharedMesh = bumper1;
						}
					}
					
					if (bumper.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bumper_f2"))
					{
						bumper.GetComponent<MeshFilter>().sharedMesh = bumper2;
					}
					
					if (bumper.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bumper_f3"))
					{
						bumper.GetComponent<MeshFilter>().sharedMesh = bumper3;
					}
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN405").gameObject.GetComponent<MeshFilter>().sharedMesh = bumper1;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN405B").gameObject.GetComponent<MeshFilter>().sharedMesh = bumper2;
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN405C").gameObject.GetComponent<MeshFilter>().sharedMesh = bumper3;
				
				HutongGames.PlayMaker.Actions.SetProperty Bumper1FSM = CorrisGO.transform.Find("Assemblies/VINP_BumperFront").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				Bumper1FSM.targetProperty.ObjectParameter = bumper1;
				HutongGames.PlayMaker.Actions.SetProperty Bumper2FSM = CorrisGO.transform.Find("Assemblies/VINP_BumperFront").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 2").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				Bumper2FSM.targetProperty.ObjectParameter = bumper2;
				HutongGames.PlayMaker.Actions.SetProperty Bumper3FSM = CorrisGO.transform.Find("Assemblies/VINP_BumperFront").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair 3").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				Bumper3FSM.targetProperty.ObjectParameter = bumper3;
			}
			
			if(BootlidToggle.GetValue())
			{
				GameObject bundlebootlidtrim = Object.Instantiate(bundle.LoadAsset<GameObject>("body_bootlid_trim.prefab"));
				Mesh bootlidtrim = bundlebootlidtrim.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlebootlidtrim);
				
				foreach (GameObject bootlid in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Bootlid(VINXX)"))
				{
					if (!bootlid.transform.Find("trim").gameObject.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bootlid_trim2"))
					{
						if (bootlid.transform.Find("trim").gameObject.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_bootlid_trim"))
						{
							bootlid.transform.Find("trim").gameObject.GetComponent<MeshFilter>().sharedMesh = bootlidtrim;
						}
					}
				}
				
				Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN412").transform.Find("trim").gameObject.GetComponent<MeshFilter>().sharedMesh = bootlidtrim;
			}
			
			if(RegplateToggle.GetValue())
			{
				CorrisGO.transform.Find("Assemblies/VINP_RegPlateF").transform.localEulerAngles = new Vector3 (350f, 0f, 90f);
				CorrisGO.transform.Find("Assemblies/VINP_RegPlateR").transform.localEulerAngles = new Vector3 (15f, 0f, 270f);
			}
			
			if(RadioToggle.GetValue())
			{
				HutongGames.PlayMaker.Actions.GetFsmBool antenna1 = CorrisGO.transform.Find("Functions/Radio/SoundSpeakerDash").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.GetFsmBool;
				antenna1.Enabled = false;
				antenna1.storeValue.Value = true;
				HutongGames.PlayMaker.Actions.GetFsmBool antenna2 = CorrisGO.transform.Find("Functions/Radio/SoundSpeakerDash").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[1] as HutongGames.PlayMaker.Actions.GetFsmBool;
				antenna2.Enabled = false;
				antenna2.storeValue.Value = true;

				HutongGames.PlayMaker.Actions.GetFsmBool antenna3 = CorrisGO.transform.Find("Functions/Radio/SoundSpeakerBass").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.GetFsmBool;
				antenna3.Enabled = false;
				antenna3.storeValue.Value = true;
				HutongGames.PlayMaker.Actions.GetFsmBool antenna4 = CorrisGO.transform.Find("Functions/Radio/SoundSpeakerBass").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[1] as HutongGames.PlayMaker.Actions.GetFsmBool;
				antenna4.Enabled = false;
				antenna4.storeValue.Value = true;
			}
			
			if(ShelfToggle.GetValue())
			{
				GameObject bundleshelf = Object.Instantiate(bundle.LoadAsset<GameObject>("tuning_parcel_shelf.prefab"));
				Mesh shelf = bundleshelf.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundleshelf);
				
				foreach (GameObject shelfgo in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Parcel Shelf(VINXX)" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("tuning_parcel_shelf")))
				{
					shelfgo.GetComponent<MeshFilter>().sharedMesh = shelf;
					shelfgo.GetComponent<MeshRenderer>().material = CorrisGO.transform.Find("BODY/Upholstery/interior_panels").gameObject.GetComponent<MeshRenderer>().material;
				}
			}
			
			if(CDToggle.GetValue())
			{
				CorrisGO.transform.Find("Assemblies/VINP_Radio/CDPlayer1").gameObject.transform.localScale = new Vector3(1.16f, 1.16f, 1.16f);
			}
			
			if(HoodToggle.GetValue())
			{
				GameObject bundlehood = Object.Instantiate(bundle.LoadAsset<GameObject>("body_hood.prefab"));
				Mesh hood = bundlehood.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlehood);
				
				foreach(GameObject hoodgo in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "Hood(VINXX)"))
				{
					if(hoodgo.GetComponent<MeshFilter>().sharedMesh.name.Contains("body_hood"))
					{
						hoodgo.GetComponent<MeshFilter>().sharedMesh = hood;
					}
					
					if(hoodgo.GetComponent<MeshRenderer>().materials.Length == 1)
					{
						Material[] oldMats2 = hoodgo.GetComponent<MeshRenderer>().materials;
						Material[] newMats2 = new Material[oldMats2.Length + 1];
						oldMats2.CopyTo(newMats2, 0);
						ATLAS_MOTOR2.CopyTo(newMats2, 1);
						hoodgo.GetComponent<MeshRenderer>().materials = newMats2;
					}
				}
				
				GameObject PrefabHood = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(g => g.name == "VIN411").gameObject;
				PrefabHood.GetComponent<MeshFilter>().sharedMesh = hood;
				if(PrefabHood.GetComponent<MeshRenderer>().materials.Length == 1)
				{
					Material[] oldMats3 = PrefabHood.GetComponent<MeshRenderer>().materials;
					Material[] newMats3 = new Material[oldMats3.Length + 1];
					oldMats3.CopyTo(newMats3, 0);
					ATLAS_MOTOR2.CopyTo(newMats3, 1);
					PrefabHood.GetComponent<MeshRenderer>().materials = newMats3;
				}
				
				HutongGames.PlayMaker.Actions.SetProperty HoodFSM = CorrisGO.transform.Find("Assemblies/VINP_Hood").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Repair").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				HoodFSM.targetProperty.ObjectParameter = hood;
			}
			
			if(SeatbeltToggle.GetValue())
			{
				GameObject DriverSeatBelt = CorrisGO.transform.Find("Functions/Seatbelts/HandleUpPivot").gameObject;
				GameObject PassengerSeatBelt = GameObject.Instantiate(DriverSeatBelt, Vector3.zero, Quaternion.identity) as GameObject;
				Object.Destroy(PassengerSeatBelt.transform.Find("SeatbeltHandle").gameObject.GetComponent<PlayMakerFSM>());
				PassengerSeatBelt.transform.parent = CorrisGO.transform.Find("Functions/Seatbelts").transform;
				PassengerSeatBelt.transform.localPosition = new Vector3(-0.635f, -0.513f, 0.719f);
				PassengerSeatBelt.transform.localEulerAngles = new Vector3(7f, 332f, 0f);
				PassengerSeatBelt.transform.localScale = new Vector3(-1f, 1f, 1f);
			}
			
			if(KeychainToggle.GetValue())
			{
				GameObject bundlekey = Object.Instantiate(bundle.LoadAsset<GameObject>("key_satsuma.prefab"));
				Mesh key = bundlekey.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlekey);
				
				CorrisGO.transform.Find("Assemblies/VINP_SteeringColumn/Dashboard/KeyHole/Keys/CarKeyMesh").gameObject.GetComponent<MeshFilter>().sharedMesh = key;
			}
			
			if(SunvisorsToggle.GetValue())
			{
				GameObject bundlesunvisor = Object.Instantiate(bundle.LoadAsset<GameObject>("datsun_sunvisor_left.prefab"));
				Mesh sunvisor = bundlesunvisor.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlesunvisor);
				GameObject bundlemount = Object.Instantiate(bundle.LoadAsset<GameObject>("datsun_sunvisor_mount.prefab"));
				Mesh mount = bundlemount.GetComponent<MeshFilter>().mesh;
				Object.Destroy(bundlemount);
				
				GameObject SunvisorLeft = CorrisGO.transform.Find("Functions/Sunvisors/SunvisorLeft").gameObject;
				GameObject SunvisorRight = CorrisGO.transform.Find("Functions/Sunvisors/SunvisorRight").gameObject;
				
				SunvisorLeft.transform.Find("mesh").gameObject.GetComponent<MeshFilter>().sharedMesh = sunvisor;
				SunvisorRight.transform.Find("mesh").gameObject.GetComponent<MeshFilter>().sharedMesh = sunvisor;
				
				CorrisGO.transform.Find("Functions/Sunvisors").gameObject.SetActive(true);
				CorrisGO.transform.Find("Functions/Sunvisors").gameObject.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
				SunvisorLeft.transform.localPosition = new Vector3(-0.3f, 0.79f, 0.18f);
				SunvisorLeft.transform.localEulerAngles = new Vector3(280f, 335f, 18f);
				SunvisorLeft.transform.localScale = new Vector3(-1f, -1f, 1f);
				SunvisorRight.transform.localPosition = new Vector3(0.3f, 0.79f, 0.18f);
				SunvisorRight.transform.localEulerAngles = new Vector3(280f, 25f, 342f);
				SunvisorRight.transform.localScale = new Vector3(1f, -1f, -1f);
				
				HutongGames.PlayMaker.Actions.FloatClamp limit1 = SunvisorLeft.transform.Find("mesh").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[1] as HutongGames.PlayMaker.Actions.FloatClamp;
				limit1.maxValue = 155f;
				HutongGames.PlayMaker.Actions.FloatClamp limit2 = SunvisorLeft.transform.Find("mesh").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[1] as HutongGames.PlayMaker.Actions.FloatClamp;
				limit2.maxValue = 155f;
				HutongGames.PlayMaker.Actions.FloatClamp limit3 = SunvisorRight.transform.Find("mesh").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[1] as HutongGames.PlayMaker.Actions.FloatClamp;
				limit3.minValue = -155f;
				HutongGames.PlayMaker.Actions.FloatClamp limit4 = SunvisorRight.transform.Find("mesh").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[1] as HutongGames.PlayMaker.Actions.FloatClamp;
				limit4.minValue = -155f;
				
				GameObject MountLeft = new GameObject();
				MountLeft.transform.parent = SunvisorLeft.transform;
				MountLeft.transform.localPosition = Vector3.zero;
				MountLeft.transform.localEulerAngles = Vector3.zero;
				MountLeft.transform.localScale = Vector3.one;
				MountLeft.AddComponent<MeshFilter>().mesh = mount;
				MountLeft.AddComponent<MeshRenderer>().material = ATLAS_MOTOR;
				GameObject MountRight = new GameObject();
				MountRight.transform.parent = SunvisorRight.transform;
				MountRight.transform.localPosition = Vector3.zero;
				MountRight.transform.localEulerAngles = Vector3.zero;
				MountRight.transform.localScale = new Vector3 (1f, 1f, -1f);
				MountRight.AddComponent<MeshFilter>().mesh = mount;
				MountRight.AddComponent<MeshRenderer>().material = ATLAS_MOTOR;
			}
			
            bundle.Unload(false);
        }
    }
}